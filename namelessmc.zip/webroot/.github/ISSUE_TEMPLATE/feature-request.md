---
name: "\U0001F4AD Feature request"
about: Suggest a feature we can add to NamelessMC

---

<!-- Please describe the feature in as much detail as possible -->
